


//configure
CSSUtilities.define('async', false);
CSSUtilities.define('mode', 'author');


//initialize
CSSUtilities.init();


